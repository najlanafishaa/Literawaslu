<?php $__env->startSection('title', 'Laporan Perpustakaan'); ?>
<?php $__env->startSection('header_title', 'Laporan & Analitik'); ?>

<?php $__env->startSection('content'); ?>
<div class="print-header">
    <h2 style="margin: 0; font-size: 1.4rem; font-weight: bold; text-transform: uppercase;">LAPORAN REKAPITULASI HASIL PEMINJAMAN & PENGEMBALIAN BUKU</h2>
    <h4 style="margin: 5px 0 0 0; font-size: 1rem; color: #333;">PERPUSTAKAAN LITERAWASLU</h4>
    <p style="margin: 3px 0 0 0; font-size: 0.85rem; color: #555;">Periode Laporan: <?php echo e($filterLabel ?? 'Semua Waktu'); ?> &bull; Dicetak Pada: <?php echo e(now()->format('d M Y H:i')); ?></p>
</div>

<div class="welcome-banner no-print" style="margin-bottom: 25px;">
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; width: 100%;">
        <div>
            <h1>Laporan Aktivitas Perpustakaan</h1>
            <p>Rekap statistik data anggota, sirkulasi peminjaman, buku populer, dan catatan keterlambatan.</p>
        </div>
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <a href="<?php echo e(route('reports.export', request()->all())); ?>" class="btn btn-success btn-sm no-print" style="background: #16a34a; color: #ffffff; border: none; font-weight: 600; padding: 8px 16px; border-radius: 8px; box-shadow: 0 2px 6px rgba(22,163,74,0.3); display: inline-flex; align-items: center; gap: 6px;">
                <i class="ti ti-file-spreadsheet" style="font-size: 1.1rem;"></i> Export ke Excel
            </a>
            <a href="<?php echo e(route('reports.pdf', request()->all())); ?>" target="_blank" class="btn btn-primary btn-sm no-print" style="background: #D62027; color: #ffffff; border: none; font-weight: 700; padding: 8px 18px; border-radius: 8px; box-shadow: 0 4px 12px rgba(214,32,39,0.4); display: inline-flex; align-items: center; gap: 6px;">
                <i class="ti ti-file-type-pdf" style="font-size: 1.15rem;"></i> Cetak Laporan / PDF
            </a>
        </div>
    </div>
</div>

<!-- Date Filter Panel -->
<div class="card" style="margin-bottom: 25px;">
    <div class="card-body" style="padding: 15px 20px;">
        <form action="<?php echo e(route('reports.index')); ?>" method="GET" style="display: flex; justify-content: space-between; align-items: center; gap: 15px; flex-wrap: wrap; margin: 0;">
            <div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
                <span style="font-size: 0.85rem; font-weight: 700; color: var(--gray-700); margin-right: 5px;"><i class="ti ti-calendar"></i> Filter Waktu Laporan:</span>
                <a href="<?php echo e(route('reports.index', ['filter' => 'all'])); ?>" class="btn <?php echo e(request('filter', 'all') === 'all' ? 'btn-primary' : 'btn-outline'); ?> btn-sm" style="padding: 6px 12px; font-size: 0.8rem;">Semua</a>
                <a href="<?php echo e(route('reports.index', ['filter' => 'today'])); ?>" class="btn <?php echo e(request('filter') === 'today' ? 'btn-primary' : 'btn-outline'); ?> btn-sm" style="padding: 6px 12px; font-size: 0.8rem;">Hari Ini</a>
                <a href="<?php echo e(route('reports.index', ['filter' => 'week'])); ?>" class="btn <?php echo e(request('filter') === 'week' ? 'btn-primary' : 'btn-outline'); ?> btn-sm" style="padding: 6px 12px; font-size: 0.8rem;">Minggu Ini</a>
                <a href="<?php echo e(route('reports.index', ['filter' => 'month'])); ?>" class="btn <?php echo e(request('filter') === 'month' ? 'btn-primary' : 'btn-outline'); ?> btn-sm" style="padding: 6px 12px; font-size: 0.8rem;">Bulan Ini</a>
                <a href="<?php echo e(route('reports.index', ['filter' => 'year'])); ?>" class="btn <?php echo e(request('filter') === 'year' ? 'btn-primary' : 'btn-outline'); ?> btn-sm" style="padding: 6px 12px; font-size: 0.8rem;">Tahun Ini</a>
            </div>
            
            <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                <input type="hidden" name="filter" value="custom">
                <input type="date" name="start_date" class="form-control" style="width: auto; padding: 5px 10px; font-size: 0.8rem; height: 32px;" value="<?php echo e(request('start_date')); ?>" required>
                <span style="color: var(--gray-600); font-size: 0.8rem;">s/d</span>
                <input type="date" name="end_date" class="form-control" style="width: auto; padding: 5px 10px; font-size: 0.8rem; height: 32px;" value="<?php echo e(request('end_date')); ?>" required>
                <button type="submit" class="btn btn-secondary btn-sm" style="padding: 6px 12px; font-size: 0.8rem; height: 32px;">Filter</button>
            </div>
        </form>
        <?php if(isset($filterLabel)): ?>
            <div style="margin-top: 10px; font-size: 0.8rem; color: var(--gray-600); font-weight: bold;">
                <i class="ti ti-filter" style="color: var(--primary); margin-right: 4px;"></i> Periode Aktif: <?php echo e($filterLabel); ?>

            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Laporan Metrics Grid -->
<div class="grid-stats" style="margin-bottom: 25px;">
    <div class="stat-card">
        <div class="stat-info">
            <h3>Total Buku Dipinjam (Periode)</h3>
            <p><?php echo e($totalBorrowCount); ?> Kali</p>
        </div>
        <div class="stat-icon red">
            <i class="ti ti-arrows-shuffle"></i>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-info">
            <h3>Jumlah Keterlambatan</h3>
            <p style="<?php echo e($lateCount > 0 ? 'color: var(--primary);' : ''); ?>"><?php echo e($lateCount); ?> Kali</p>
        </div>
        <div class="stat-icon red">
            <i class="ti ti-clock"></i>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-info">
            <h3>Total Sanksi Donasi Buku</h3>
            <p><?php echo e($totalFineAmount); ?> Buku</p>
        </div>
        <div class="stat-icon red">
            <i class="ti ti-books"></i>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-info">
            <h3>Buku Fisik Sudah Dipenuhi</h3>
            <p style="color: var(--dark);"><?php echo e($paidFineAmount); ?> Buku</p>
        </div>
        <div class="stat-icon yellow">
            <i class="ti ti-circle-check"></i>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-info">
            <h3>Buku Fisik Belum Dipenuhi</h3>
            <p style="color: var(--primary);"><?php echo e($unpaidFineAmount); ?> Buku</p>
        </div>
        <div class="stat-icon red">
            <i class="ti ti-alert-circle"></i>
        </div>
    </div>
</div>

<!-- Charts Grid -->
<div class="dashboard-grid" style="margin-bottom: 30px;">
    <!-- Monthly Borrowing Trend -->
    <div class="card">
        <div class="card-header">
            <h2><i class="ti ti-chart-line" style="color: var(--primary); margin-right: 8px;"></i> Tren Peminjaman per Bulan</h2>
        </div>
        <div class="card-body" style="position: relative; height: 300px;">
            <canvas id="monthlyTrendChart"></canvas>
        </div>
    </div>

    <!-- Inventory Availability (Donut) -->
    <div class="card">
        <div class="card-header">
            <h2><i class="ti ti-stack-2" style="color: var(--secondary); margin-right: 8px;"></i> Ketersediaan Koleksi Buku</h2>
        </div>
        <div class="card-body" style="position: relative; height: 300px; display: flex; justify-content: center; align-items: center;">
            <div style="width: 220px; height: 220px;">
                <canvas id="availabilityChart"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Detailed Logs Tabs/Tables -->
<div class="card" style="margin-bottom: 30px;">
    <div class="card-header">
        <h2><i class="ti ti-users" style="color: var(--primary); margin-right: 8px;"></i> Anggota Terdaftar</h2>
        <span class="badge badge-success"><?php echo e($totalMembers); ?> Terdaftar</span>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table-custom">
                <thead>
                    <tr>
                        <th>Kode Member</th>
                        <th>Nama Anggota</th>
                        <th>Email</th>
                        <th>Total Pinjam</th>
                        <th>Poin</th>
                        <th>Tanggal Gabung</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $membersList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="font-family: monospace; font-weight: 700; color: var(--dark);"><?php echo e($m->member_code); ?></td>
                            <td><strong><?php echo e($m->user->name); ?></strong></td>
                            <td><?php echo e($m->user->email); ?></td>
                            <td><?php echo e($m->total_loans); ?> kali</td>
                            <td><span class="badge badge-warning"><?php echo e($m->points); ?></span></td>
                            <td><?php echo e($m->created_at->format('d M Y')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="dashboard-grid">
    <!-- Left Column: Overdue and Late Return Audit -->
    <div class="card">
        <div class="card-header">
            <h2><i class="ti ti-alert-triangle" style="color: var(--primary); margin-right: 8px;"></i> Daftar Denda & Sanksi Keterlambatan</h2>
        </div>
        <div class="card-body">
            <?php if($overdueBorrows->isEmpty() && empty($returnedLateBorrows)): ?>
                <p style="font-size: 0.85rem; color: var(--gray-600); text-align: center; padding: 20px 0;">Tidak ada catatan denda / sanksi keterlambatan saat ini.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table-custom">
                        <thead>
                            <tr>
                                <th>Nama Member</th>
                                <th>Judul Buku</th>
                                <th>Tanggal Jatuh Tempo</th>
                                <th>Hari Terlambat</th>
                                <th>Jenis Sanksi</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $overdueBorrows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ob): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $due = \Carbon\Carbon::parse($ob->due_date);
                                    $lateDays = \Carbon\Carbon::now()->startOfDay()->diffInDays($due);
                                ?>
                                <tr>
                                    <td><strong><?php echo e($ob->member->user->name); ?></strong></td>
                                    <td><?php echo e($ob->book->title); ?></td>
                                    <td><?php echo e($due->format('d M Y')); ?></td>
                                    <td><span style="color: var(--primary); font-weight: 700;"><?php echo e($lateDays); ?> Hari</span></td>
                                    <td>
                                        <?php if($lateDays <= 3): ?>
                                            Pengurangan 10 Poin per Hari
                                        <?php else: ?>
                                            Wajib Donasi 1 Buku Fisik + Pengurangan 10 Poin per Hari
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($lateDays <= 3): ?>
                                            <span class="badge badge-success">Diprores Otomatis</span>
                                        <?php else: ?>
                                            <?php if($ob->fine_status === 'paid'): ?>
                                                <span class="badge badge-success">Sudah Dipenuhi</span>
                                            <?php else: ?>
                                                <span class="badge badge-danger">Belum Dipenuhi</span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $returnedLateBorrows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $due = \Carbon\Carbon::parse($rl->due_date);
                                    $return = \Carbon\Carbon::parse($rl->return_date);
                                    $lateDays = $return->diffInDays($due);
                                ?>
                                <tr>
                                    <td><strong><?php echo e($rl->member->user->name); ?></strong></td>
                                    <td><?php echo e($rl->book->title); ?></td>
                                    <td><?php echo e($due->format('d M Y')); ?></td>
                                    <td><span style="color: var(--primary); font-weight: 700;"><?php echo e($lateDays); ?> Hari</span></td>
                                    <td>
                                        <?php if($lateDays <= 3): ?>
                                            Pengurangan 10 Poin per Hari
                                        <?php else: ?>
                                            Wajib Donasi 1 Buku Fisik + Pengurangan 10 Poin per Hari
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($lateDays <= 3): ?>
                                            <span class="badge badge-success">Sudah Dipenuhi</span>
                                        <?php else: ?>
                                            <?php if($rl->fine_status === 'paid'): ?>
                                                <span class="badge badge-success">Sudah Dipenuhi</span>
                                            <?php else: ?>
                                                <span class="badge badge-danger">Belum Dipenuhi</span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Right Column: Popular Books Ranking -->
    <div class="card">
        <div class="card-header">
            <h2><i class="ti ti-flame" style="color: var(--secondary); margin-right: 8px;"></i> Peringkat Buku Paling Sering Dipinjam</h2>
        </div>
        <div class="card-body">
            <?php if($popularBooks->isEmpty()): ?>
                <p style="text-align: center; color: var(--gray-600); padding: 20px;">Belum ada peringkat data.</p>
            <?php else: ?>
                <ul style="list-style: none; display: flex; flex-direction: column; gap: 15px;">
                    <?php $__currentLoopData = $popularBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li style="display: flex; align-items: center; justify-content: space-between; padding-bottom: 12px; border-bottom: 1px solid var(--gray-100);">
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <span style="font-size: 1.1rem; font-weight: 700; color: <?php echo e($index == 0 ? 'var(--secondary)' : ($index == 1 ? 'var(--primary)' : 'var(--gray-600)')); ?>;">
                                    #<?php echo e($index + 1); ?>

                                </span>
                                <div>
                                    <div style="font-weight: 600; color: var(--dark);"><?php echo e($popular->book->title); ?></div>
                                    <div style="font-size: 0.8rem; color: var(--gray-600);"><?php echo e($popular->book->author); ?></div>
                                </div>
                            </div>
                            <span class="badge badge-success" style="font-weight: 700;"><?php echo e($popular->total); ?>x Pinjam</span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Reward Member Stats Table -->
<div class="card" style="margin-top: 30px; margin-bottom: 25px;">
    <div class="card-header">
        <h2><i class="ti ti-medal" style="color: #f1c40f; margin-right: 8px;"></i> Statistik Reward Member (Top 10 Poin Terbanyak)</h2>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table-custom">
                <thead>
                    <tr>
                        <th style="width: 80px;">Peringkat</th>
                        <th>Nama Anggota</th>
                        <th>Kode Anggota</th>
                        <th>Total Peminjaman</th>
                        <th>Saldo Poin</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $memberRewardStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $mr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <strong>#<?php echo e($index + 1); ?></strong>
                            </td>
                            <td><strong><?php echo e($mr->user->name); ?></strong></td>
                            <td style="font-family: monospace;"><?php echo e($mr->member_code); ?></td>
                            <td><?php echo e($mr->total_loans); ?> Kali</td>
                            <td>
                                <span class="badge badge-warning" style="font-weight: bold; font-size: 0.82rem; padding: 4px 8px; display: inline-flex; align-items: center; gap: 4px;">
                                    <i class="ti ti-star"></i> <?php echo e($mr->points); ?> Poin
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        // 1. Monthly Borrow Trend Chart
        const trendCtx = document.getElementById('monthlyTrendChart').getContext('2d');
        
        // Prepare chart data from PHP controller variables
        const monthlyLabels = [
            <?php $__currentLoopData = $monthlyTrends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                "<?php echo e(substr($month, 5)); ?>",
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ];
        
        const monthlyData = [
            <?php $__currentLoopData = $monthlyTrends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($count); ?>,
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ];

        // Ensure chart has data
        if (monthlyLabels.length === 0) {
            monthlyLabels.push("Belum ada");
            monthlyData.push(0);
        }

        const primaryColor = getComputedStyle(document.documentElement).getPropertyValue('--primary').trim() || '#D62027';
        const primaryColorRgb = getComputedStyle(document.documentElement).getPropertyValue('--primary-rgb').trim() || '214, 32, 39';

        new Chart(trendCtx, {
            type: 'line',
            data: {
                labels: monthlyLabels,
                datasets: [{
                    label: 'Jumlah Transaksi',
                    data: monthlyData,
                    borderColor: primaryColor,
                    backgroundColor: `rgba(${primaryColorRgb}, 0.1)`,
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });

        // 2. Book Availability Donut Chart
        const availCtx = document.getElementById('availabilityChart').getContext('2d');
        new Chart(availCtx, {
            type: 'doughnut',
            data: {
                labels: ['Tersedia', 'Sedang Dipinjam'],
                datasets: [{
                    data: [<?php echo e($availableBooks); ?>, <?php echo e($borrowedBooksCount); ?>],
                    backgroundColor: ['#22c55e', primaryColor],
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            boxWidth: 12,
                            font: {
                                family: 'Outfit'
                            }
                        }
                    }
                },
                cutout: '70%'
            }
        });
    });
</script>

<style>
    @media print {
        body {
            background: #fff !important;
            color: #000 !important;
            font-family: Arial, sans-serif !important;
        }
        .sidebar, .header-nav, .welcome-banner, .no-print, form, .btn, .card-header .btn {
            display: none !important;
        }
        .main-wrapper {
            margin-left: 0 !important;
            padding: 0 !important;
        }
        .content-body {
            padding: 0 !important;
        }
        .card {
            border: 1px solid #ccc !important;
            box-shadow: none !important;
            margin-bottom: 20px !important;
            break-inside: avoid;
        }
        .table-custom {
            width: 100% !important;
            border-collapse: collapse !important;
        }
        .table-custom th, .table-custom td {
            border: 1px solid #000 !important;
            padding: 6px 8px !important;
            font-size: 11px !important;
        }
        .table-custom th {
            background-color: #f0f0f0 !important;
            color: #000 !important;
        }
        .print-header {
            display: block !important;
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
        }
    }
    .print-header {
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Literawaslu\resources\views/reports/index.blade.php ENDPATH**/ ?>