<?php $__env->startSection('title', 'Transaksi Peminjaman'); ?>
<?php $__env->startSection('header_title', 'Peminjaman & Pengembalian'); ?>

<?php $__env->startSection('content'); ?>



<!-- Active Transactions List -->
<div class="card">
    <div class="card-header">
        <h2><i class="ti ti-list-check" style="color: var(--dark); margin-right: 8px;"></i> Daftar Peminjaman Aktif (Sedang Dipinjam)</h2>
        <span class="badge badge-warning"><?php echo e($activeBorrows->count()); ?> Peminjaman</span>
    </div>
    <div class="card-body">
        <?php if($activeBorrows->isEmpty()): ?>
            <p style="text-align: center; color: var(--gray-600); padding: 30px;">Tidak ada transaksi peminjaman aktif saat ini.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table-custom">
                    <thead>
                        <tr>
                            <th>Buku</th>
                            <th>Jenis Buku</th>
                            <th>Pengguna</th>
                            <th>Tgl Pinjam</th>
                            <th>Jatuh Tempo</th>
                            <th>Status Sisa</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $activeBorrows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $due = \Carbon\Carbon::parse($borrow->due_date);
                                $now = \Carbon\Carbon::now()->startOfDay();
                                $diff = $now->diffInDays($due, false);
                            ?>
                            <tr>
                                <td>
                                    <div style="font-weight: 600;"><?php echo e($borrow->book->title); ?></div>
                                    <div style="font-size: 0.8rem; color: var(--gray-600); font-family: monospace;"><?php echo e($borrow->book->barcode); ?></div>
                                </td>
                                <td>
                                    <?php if($borrow->book->is_online): ?>
                                        <span class="badge badge-online">Online</span>
                                    <?php else: ?>
                                        <span class="badge badge-offline">Offline</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div style="font-weight: 500;"><?php echo e($borrow->member->user->name); ?></div>
                                    <div style="font-size: 0.8rem; color: var(--gray-600); font-weight: 600;"><?php echo e($borrow->member->member_code); ?></div>
                                </td>
                                <td><?php echo e($borrow->borrow_date->format('d M Y')); ?></td>
                                <td><?php echo e($borrow->due_date->format('d M Y')); ?></td>
                                <td>
                                    <?php if($diff < 0): ?>
                                        <span class="badge badge-danger">Terlambat <?php echo e(abs($diff)); ?> Hari</span>
                                    <?php elseif($diff == 0): ?>
                                        <span class="badge badge-warning">Hari Ini!</span>
                                    <?php else: ?>
                                        <span class="badge badge-success"><?php echo e($diff); ?> Hari</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('borrows.checkin')); ?>" method="POST" style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="barcode" value="<?php echo e($borrow->book->barcode); ?>">
                                        <button type="submit" class="btn btn-secondary btn-sm" style="font-size: 0.75rem; padding: 6px 12px;">
                                            <i class="ti ti-corner-down-left"></i> Kembalikan
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Unpaid Fines List -->
<?php
    $unpaidFines = \App\Models\Borrow::where('fine_status', 'unpaid')
        ->with(['member.user', 'book'])
        ->orderBy('created_at', 'desc')
        ->get();
?>

<div class="card" style="margin-top: 25px; margin-bottom: 25px;">
    <div class="card-header">
        <h2><i class="ti ti-book-plus" style="color: var(--primary); margin-right: 8px;"></i> Daftar Sanksi Wajib Donasi Buku Fisik (> 3 Hari Terlambat)</h2>
        <span class="badge badge-danger"><?php echo e($unpaidFines->count()); ?> Transaksi</span>
    </div>
    <div class="card-body">
        <?php if($unpaidFines->isEmpty()): ?>
            <p style="text-align: center; color: var(--gray-600); padding: 30px;">Tidak ada sanksi buku fisik yang belum dipenuhi saat ini.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table-custom">
                    <thead>
                        <tr>
                            <th>Buku Dipinjam</th>
                            <th>Nama Pengguna</th>
                            <th>Tanggal Jatuh Tempo</th>
                            <th>Tanggal Kembali</th>
                            <th>Sanksi Wajib</th>
                            <th>Aksi Konfirmasi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $unpaidFines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fineBorrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div style="font-weight: 600;"><?php echo e($fineBorrow->book->title); ?></div>
                                    <div style="font-size: 0.8rem; color: var(--gray-600); font-family: monospace;"><?php echo e($fineBorrow->book->barcode); ?></div>
                                </td>
                                <td>
                                    <div style="font-weight: 500;"><?php echo e($fineBorrow->member->user->name); ?></div>
                                    <div style="font-size: 0.8rem; color: var(--gray-600); font-weight: 600;"><?php echo e($fineBorrow->member->member_code); ?></div>
                                </td>
                                <td><?php echo e($fineBorrow->due_date->format('d M Y')); ?></td>
                                <td><?php echo e($fineBorrow->return_date ? $fineBorrow->return_date->format('d M Y') : '-'); ?></td>
                                <td>
                                    <strong style="color: var(--primary); font-size: 0.9rem;">1 Buku Fisik Baru</strong>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('borrows.pay_fine', $fineBorrow->id)); ?>" method="POST" style="margin: 0;">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-primary btn-sm" style="font-size: 0.75rem; padding: 6px 12px; display: inline-flex; align-items: center; gap: 4px; height: auto;">
                                            <i class="ti ti-check"></i> Konfirmasi Terima Buku
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Literawaslu\resources\views/dashboards/petugas_borrows.blade.php ENDPATH**/ ?>