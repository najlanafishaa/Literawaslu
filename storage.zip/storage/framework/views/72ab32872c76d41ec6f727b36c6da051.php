<?php $__env->startSection('title', 'Kelola Buku'); ?>
<?php $__env->startSection('header_title', 'Kelola Koleksi Buku'); ?>

<?php $__env->startSection('content'); ?>
<div class="card" style="margin-bottom: 25px;">
    <div class="card-body" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:15px; padding:20px;">
        <form action="<?php echo e(route('books.index')); ?>" method="GET" style="display: flex; gap: 10px; flex: 1; max-width: 500px;">
            <input type="text" name="search" class="form-control" placeholder="Cari judul, penulis, atau barcode..." value="<?php echo e(request('search')); ?>">
            <button type="submit" class="btn btn-primary"><i class="ti ti-search"></i> Cari</button>
            <?php if(request('search')): ?>
                <a href="<?php echo e(route('books.index')); ?>" class="btn btn-outline"><i class="ti ti-rotate"></i> Atur Ulang</a>
            <?php endif; ?>
        </form>
        
        <a href="<?php echo e(route('books.create')); ?>" class="btn btn-secondary">
            <i class="ti ti-plus"></i> Tambah Buku Baru
        </a>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2>Daftar Koleksi Buku</h2>
        <span class="badge badge-success"><?php echo e($books->count()); ?> Total Buku</span>
    </div>
    
    <div class="card-body">
        <?php if($books->isEmpty()): ?>
            <p style="text-align: center; color: var(--gray-600); padding: 20px;">Tidak ada koleksi buku yang ditemukan.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table-custom">
                    <thead>
                        <tr>
                            <th>Barcode</th>
                            <th>Buku</th>
                            <th>Penulis</th>
                            <th>Jenis Buku</th>
                            <th>Stok</th>
                            <th>Kategori</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="font-family: monospace; font-weight: 600;"><?php echo e($book->barcode); ?></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 12px;">
                                        <div style="width:35px; height:50px; border-radius:4px; overflow:hidden; background-color:var(--gray-100); border:1px solid var(--gray-200); display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                                            <?php if($book->cover_image): ?>
                                                <img src="<?php echo e(asset($book->cover_image)); ?>" alt="Sampul" style="width: 100%; height: 100%; object-fit: cover;">
                                            <?php else: ?>
                                                <div style="width: 100%; height: 100%; background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); display: flex; align-items: center; justify-content: center; color: var(--light);">
                                                    <i class="ti ti-book-2" style="font-size: 0.8rem;"></i>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div>
                                            <div style="font-weight: 600; color: var(--dark);"><?php echo e($book->title); ?></div>
                                            <small style="color: var(--gray-600);"><?php echo e($book->publisher); ?> (<?php echo e($book->year); ?>)</small>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo e($book->author); ?></td>
                                <td>
                                    <?php if($book->drive_link && $book->stock > 0): ?>
                                        <span class="badge badge-online">Online</span>
                                        <span class="badge badge-offline">Offline</span>
                                    <?php elseif($book->drive_link || $book->is_online): ?>
                                        <span class="badge badge-online">Online</span>
                                    <?php else: ?>
                                        <span class="badge badge-offline">Offline</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span style="font-weight: 600; color: var(--dark);"><?php echo e($book->available_stock); ?></span>
                                    <span style="color: var(--gray-500);">/ <?php echo e($book->stock); ?></span>
                                </td>
                                <td><?php echo e($book->category); ?></td>
                                <td>
                                    <?php if($book->available_stock > 0): ?>
                                        <span class="badge badge-success">Tersedia</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Habis</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div style="display: flex; gap: 8px;">
                                        <a href="<?php echo e(route('books.edit', $book->id)); ?>" class="btn btn-outline btn-sm" title="Edit Buku" style="padding: 6px 10px;">
                                            <i class="ti ti-pencil"></i>
                                        </a>
                                        <form action="<?php echo e(route('books.destroy', $book->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus buku ini dari sistem?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-outline btn-sm" title="Hapus Buku" style="padding:6px 10px; color:var(--primary); border-color:rgba(var(--primary-rgb),0.2);">
                                                <i class="ti ti-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Literawaslu\resources\views/books/index.blade.php ENDPATH**/ ?>