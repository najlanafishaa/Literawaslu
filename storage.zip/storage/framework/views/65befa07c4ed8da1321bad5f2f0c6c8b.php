<?php $__env->startSection('title', 'Katalog Buku'); ?>
<?php $__env->startSection('header_title', 'Katalog Buku'); ?>

<?php $__env->startSection('content'); ?>
<?php if(auth()->user()->member->status === 'pending'): ?>
    <div class="alert alert-warning" style="background-color: #fff3cd; color: #856404; padding: 15px; border-radius: 4px; margin-bottom: 20px; border: 1px solid #ffeeba;">
        <strong>Perhatian!</strong> Akun Anda sedang menunggu verifikasi dari Admin. Anda belum bisa meminjam buku secara online sampai akun Anda disetujui.
    </div>
<?php endif; ?>
<?php if(auth()->user()->member->status === 'rejected'): ?>
    <div class="alert alert-danger" style="background-color: #f8d7da; color: #721c24; padding: 15px; border-radius: 4px; margin-bottom: 20px; border: 1px solid #f5c6cb;">
        <strong>Pendaftaran Ditolak!</strong> Akun Anda tidak disetujui oleh Admin. Silakan hubungi admin perpustakaan untuk informasi lebih lanjut.
    </div>
<?php endif; ?>

<div class="card" style="margin-bottom: 25px;">
    <div class="card-body">
        <form id="catalogFilter" action="<?php echo e(route('catalog')); ?>" method="GET" class="catalog-filter-form">
            <div class="filter-search">
                <input type="text" name="search" class="form-control" placeholder="Cari judul buku, penulis, atau barcode..." value="<?php echo e(request('search')); ?>">
            </div>
            
            <div class="filter-select">
                <select name="category" class="form-control" onchange="this.form.submit()">
                    <option value="">Semua Kategori</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category); ?>" <?php echo e(request('category') === $category ? 'selected' : ''); ?>><?php echo e(ucwords(strtolower($category))); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            
            <div class="filter-select">
                <select name="borrow_type" id="borrowTypeSelect" class="form-control" onchange="filterCatalogCards(this.value)">
                    <option value="" <?php echo e(request('borrow_type') == '' ? 'selected' : ''); ?>>Semua Buku</option>
                    <option value="online" <?php echo e(request('borrow_type') === 'online_only' || request('borrow_type') === 'online' ? 'selected' : ''); ?>>Buku Online</option>
                    <option value="offline" <?php echo e(request('borrow_type') === 'offline_only' || request('borrow_type') === 'offline' ? 'selected' : ''); ?>>Buku Offline</option>
                </select>
            </div>
            
            <div class="filter-actions">
                <button type="submit" class="btn btn-primary">
                    <i class="ti ti-search"></i> Cari
                </button>
                <?php if(request()->anyFilled(['search', 'category', 'borrow_type'])): ?>
                    <a href="<?php echo e(route('catalog')); ?>" class="btn btn-outline">
                        <i class="ti ti-rotate"></i> Atur Ulang
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<div class="catalog-grid" id="catalogGrid">
    <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="book-card" data-book-type="<?php echo e($book->is_online ? 'online' : 'offline'); ?>" style="position: relative; overflow: hidden; display: flex; flex-direction: column; min-height: 460px; padding: 0; border: 1px solid rgba(0,0,0,0.06); border-radius: 14px; background: var(--light);">
            <!-- Blur Cover Background -->
            <div style="position: absolute; top: 0; left: 0; width: 100%; height: 160px; overflow: hidden; z-index: 1;">
                <div style="width: 100%; height: 100%; background-image: url('<?php echo e($book->cover_image ? asset($book->cover_image) : asset('images/logo-bawaslu.png')); ?>'); background-size: cover; background-position: center; filter: blur(12px) brightness(0.55); transform: scale(1.15);"></div>
            </div>
            
            <!-- Foreground Elements -->
            <div style="position: relative; z-index: 2; padding: 25px 20px 0; display: flex; flex-direction: column; align-items: center; text-align: center; margin-top: 15px;">
                <!-- Foreground Cover Image -->
                <div style="width: 110px; height: 155px; border-radius: 8px; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.35); background-color: #f0f0f0; display: flex; align-items: center; justify-content: center; border: 1px solid rgba(255,255,255,0.2);">
                    <?php if($book->cover_image): ?>
                        <img src="<?php echo e(asset($book->cover_image)); ?>" alt="Sampul <?php echo e($book->title); ?>" style="width: 100%; height: 100%; object-fit: cover;">
                    <?php else: ?>
                        <!-- Elegant Book Icon Placeholder with gradient -->
                        <div style="width: 100%; height: 100%; background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); display: flex; flex-direction: column; align-items: center; justify-content: center; color: var(--light); padding: 10px;">
                            <i class="ti ti-book-2" style="font-size: 2.2rem; margin-bottom: 5px;"></i>
                            <span style="font-size: 0.55rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">Tanpa Sampul</span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Card Body Content -->
            <div style="flex-grow: 1; padding: 15px 20px 20px; display: flex; flex-direction: column; justify-content: space-between; z-index: 2; background-color: var(--light);">
                <div style="text-align: center;">
                    <div style="display: flex; align-items: center; justify-content: center; gap: 6px; margin-bottom: 6px; flex-wrap: wrap;">
                        <?php if($book->drive_link && $book->stock > 0): ?>
                            <span class="badge badge-online"><i class="ti ti-device-tablet"></i> Online</span>
                            <span class="badge badge-offline"><i class="ti ti-book"></i> Offline</span>
                        <?php elseif($book->drive_link || $book->is_online): ?>
                            <span class="badge badge-online"><i class="ti ti-device-tablet"></i> Online</span>
                        <?php else: ?>
                            <span class="badge badge-offline"><i class="ti ti-book"></i> Offline</span>
                        <?php endif; ?>
                        <span style="font-size: 0.72rem; color: var(--gray-400);">&bull;</span>
                        <span class="book-category" style="font-size: 0.7rem; text-transform: uppercase; font-weight: 700; color: var(--primary); letter-spacing: 0.3px;"><?php echo e($book->category); ?></span>
                    </div>
                    <h3 class="book-title" style="font-size: 0.95rem; font-weight: 700; color: var(--dark); line-height: 1.3; margin-bottom: 4px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; height: 38px;"><?php echo e($book->title); ?></h3>
                    <p class="book-author" style="font-size: 0.8rem; color: var(--gray-600); margin-bottom: 5px;">Oleh: <?php echo e($book->author); ?></p>
                    
                    <!-- Overall Rating -->
                    <div style="margin-top: 5px; display: flex; justify-content: center; align-items: center; gap: 5px; font-size: 0.82rem; color: #f1c40f;">
                        <?php if($book->reviews->count() > 0): ?>
                            <div style="display: flex; gap: 2px;">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <i class="<?php echo e($i <= round($book->average_rating) ? 'ti ti-star-filled' : 'ti ti-star'); ?>"></i>
                                <?php endfor; ?>
                            </div>
                            <span style="color: var(--gray-700); font-weight: bold; margin-left: 3px;"><?php echo e($book->average_rating); ?></span>
                            <span style="color: var(--gray-500); font-size: 0.72rem;">(<?php echo e($book->reviews->count()); ?> Ulasan)</span>
                        <?php else: ?>
                            <span style="color: var(--gray-400); font-size: 0.72rem; font-style: italic;">Belum ada ulasan</span>
                        <?php endif; ?>
                    </div>

                    <div style="font-size: 0.75rem; color: var(--gray-600); display: flex; justify-content: center; gap: 10px; margin-top: 6px;">
                        <span><i class="ti ti-building-bank"></i> <?php echo e($book->publisher); ?></span>
                        <span>•</span>
                        <span><?php echo e($book->year); ?></span>
                    </div>
                </div>
                
                <div style="border-top: 1px solid var(--gray-100); padding-top: 12px; margin-top: 12px;">
                    <!-- Stock Ratio Info -->
                    <div style="display: flex; justify-content: space-between; font-size: 0.78rem; margin-bottom: 8px; align-items: center; flex-wrap: wrap; gap: 4px;">
                        <span style="color: var(--gray-600);"><i class="ti ti-stack-2"></i> Stok:</span>
                        <span style="font-weight: 700; color: <?php echo e($book->available_stock > 0 ? 'var(--success)' : 'var(--primary)'); ?>">
                            <?php echo e($book->available_stock); ?> / <?php echo e($book->stock); ?> Buku
                        </span>
                    </div>
                    
                    <div class="book-footer" style="border: none; padding: 0; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 4px;">
                        <span class="book-status">
                            <?php if($book->available_stock > 0): ?>
                                <span class="badge badge-success" style="background-color: rgba(40,167,69,0.1); color: var(--success); font-weight: 700; letter-spacing: 0.3px;">✦ Tersedia</span>
                            <?php else: ?>
                                <span class="badge badge-danger" style="background-color: rgba(214,32,39,0.1); color: var(--primary);"><i class="ti ti-ban"></i> Kosong</span>
                            <?php endif; ?>
                        </span>
                        <span style="font-size: 0.75rem; color: var(--gray-600); font-family: monospace;"><?php echo e($book->barcode); ?></span>
                    </div>
                    
                    <div style="margin-top: 15px; display: flex; flex-direction: column; gap: 8px;">
                        <?php if(auth()->user()->member->status === 'active'): ?>
                            <?php if($book->drive_link && $book->available_stock > 0): ?>
                                
                                <form action="<?php echo e(route('member.request_borrow')); ?>" method="POST" style="margin: 0;">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">
                                    <input type="hidden" name="borrow_mode" value="offline">
                                    <button type="submit" class="btn btn-primary btn-sm" style="width: 100%; display: flex; justify-content: center; align-items: center; gap: 8px;">
                                        <i class="ti ti-book-upload"></i> Pinjam Fisik
                                    </button>
                                </form>

                                <?php
                                    $hasApprovedBorrow = \App\Models\Borrow::where('member_id', auth()->user()->member->id)
                                        ->where('book_id', $book->id)
                                        ->where('status', 'borrowed')
                                        ->exists();
                                ?>
                                <?php if($hasApprovedBorrow): ?>
                                    <a href="<?php echo e(route('book.read', $book->id)); ?>" class="btn btn-sm" style="width: 100%; display: flex; justify-content: center; align-items: center; gap: 8px; background-color: #4285F4; color: white; border: none; text-decoration: none; white-space: normal; text-align: center;">
                                        <i class="ti ti-brand-google-drive"></i> Baca Online
                                    </a>
                                <?php else: ?>
                                    <form action="<?php echo e(route('member.request_borrow')); ?>" method="POST" style="margin: 0;">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">
                                        <input type="hidden" name="borrow_mode" value="online">
                                        <button type="submit" class="btn btn-secondary btn-sm" style="width: 100%; display: flex; justify-content: center; align-items: center; gap: 8px;">
                                            <i class="ti ti-device-tablet"></i> Minta Akses Online
                                        </button>
                                    </form>
                                <?php endif; ?>
                            <?php elseif($book->available_stock > 0): ?>
                                
                                <form action="<?php echo e(route('member.request_borrow')); ?>" method="POST" style="margin: 0;">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">
                                    <input type="hidden" name="borrow_mode" value="offline">
                                    <button type="submit" class="btn btn-primary btn-sm" style="width: 100%; display: flex; justify-content: center; align-items: center; gap: 8px;">
                                        <i class="ti ti-send"></i> Pinjam Buku
                                    </button>
                                </form>
                            <?php elseif($book->drive_link): ?>
                                
                                <?php
                                    $hasApprovedBorrow = \App\Models\Borrow::where('member_id', auth()->user()->member->id)
                                        ->where('book_id', $book->id)
                                        ->where('status', 'borrowed')
                                        ->exists();
                                ?>
                                <?php if($hasApprovedBorrow): ?>
                                    <a href="<?php echo e(route('book.read', $book->id)); ?>" class="btn btn-sm" style="width: 100%; display: flex; justify-content: center; align-items: center; gap: 8px; background-color: #4285F4; color: white; border: none; text-decoration: none; white-space: normal; text-align: center;">
                                        <i class="ti ti-brand-google-drive"></i> Baca Online
                                    </a>
                                <?php else: ?>
                                    <form action="<?php echo e(route('member.request_borrow')); ?>" method="POST" style="margin: 0;">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">
                                        <input type="hidden" name="borrow_mode" value="online">
                                        <button type="submit" class="btn btn-primary btn-sm" style="width: 100%; display: flex; justify-content: center; align-items: center; gap: 8px;">
                                            <i class="ti ti-send"></i> Minta Akses Baca
                                        </button>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                        <button onclick="showBookDetail(<?php echo e($book->id); ?>)" class="btn btn-outline btn-sm" style="width: 100%; margin: 0; display: flex; justify-content: center; align-items: center; gap: 8px; color: var(--dark); border-color: var(--gray-300); white-space: normal; text-align: center;">
                            <i class="ti ti-zoom-in"></i> Detail Buku
                        </button>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px; background-color: var(--light); border-radius: var(--border-radius); border: 1px solid var(--gray-200);">
            <?php if(request('category') && !request('search')): ?>
                <i class="ti ti-book-2" style="font-size: 3rem; color: var(--gray-300); margin-bottom: 15px;"></i>
                <p style="font-weight: 600; color: var(--gray-700);">Belum ada buku dalam kategori "<?php echo e(request('category')); ?>"</p>
                <p style="font-size: 0.85rem; color: var(--gray-600); margin-top: 5px;">Kategori ini belum memiliki buku. Silakan cek kategori lainnya.</p>
            <?php elseif(request('search')): ?>
                <i class="ti ti-search" style="font-size: 3rem; color: var(--gray-300); margin-bottom: 15px;"></i>
                <p style="font-weight: 600; color: var(--gray-700);">Buku tidak ditemukan</p>
                <p style="font-size: 0.85rem; color: var(--gray-600); margin-top: 5px;">Tidak ada hasil untuk "<?php echo e(request('search')); ?>"<?php echo e(request('category') ? ' di kategori "'.request('category').'"' : ''); ?>. Coba kata kunci lain.</p>
            <?php else: ?>
                <i class="ti ti-folder-open" style="font-size: 3rem; color: var(--gray-300); margin-bottom: 15px;"></i>
                <p style="font-weight: 600; color: var(--gray-700);">Belum ada buku tersedia</p>
                <p style="font-size: 0.85rem; color: var(--gray-600); margin-top: 5px;">Perpustakaan belum memiliki buku. Silakan cek kembali nanti.</p>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>


<div id="bookDetailModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.55); z-index:9999; align-items:center; justify-content:center; padding:20px;">
    <div style="background:var(--light); border-radius:16px; max-width:600px; width:100%; max-height:90vh; overflow-y:auto; box-shadow:0 20px 60px rgba(0,0,0,0.3);">
        <div style="display:flex; justify-content:space-between; align-items:center; padding:20px 25px; border-bottom:1px solid var(--gray-100);">
            <h3 id="modalBookTitle" style="font-size:1.1rem; font-weight:700; color:var(--dark); margin:0; line-height:1.4;"></h3>
            <button onclick="closeBookDetail()" style="background:none; border:none; font-size:1.5rem; cursor:pointer; color:var(--gray-600); line-height:1;">&times;</button>
        </div>
        <div style="display:flex; flex-wrap:wrap; gap:20px; padding:20px 25px;">
            <div id="modalCoverWrap" style="flex-shrink:0; width:110px; height:155px; border-radius:10px; overflow:hidden; background:var(--gray-100); display:flex; align-items:center; justify-content:center;">
                <img id="modalCover" src="" alt="" style="width:100%; height:100%; object-fit:cover; display:none;">
                <div id="modalCoverIcon" style="width:100%; height:100%; background:linear-gradient(135deg,var(--primary),var(--secondary)); display:flex; flex-direction:column; align-items:center; justify-content:center; color:white;">
                    <i class="ti ti-book-2" style="font-size:2rem;"></i>
                </div>
            </div>
            <div style="flex:1; display:flex; flex-direction:column; gap:6px;">
                <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                    <span id="modalCategory" style="font-size:0.72rem; font-weight:700; text-transform:uppercase; color:var(--primary);"></span>
                    <span style="font-size:0.72rem; color:var(--gray-400);">&bull;</span>
                    <span id="modalTypeBadgeWrap"></span>
                </div>
                <p id="modalAuthor" style="font-size:0.88rem; color:var(--gray-700); margin:0;"></p>
                <p id="modalPublisher" style="font-size:0.82rem; color:var(--gray-600); margin:0;"></p>
                <p id="modalYear" style="font-size:0.82rem; color:var(--gray-600); margin:0;"></p>
                <p id="modalBarcode" style="font-size:0.78rem; color:var(--gray-500); font-family:monospace; margin:0;"></p>
                <div id="modalStock" style="font-size:0.82rem; font-weight:600; margin-top:4px;"></div>
                <div id="modalRatingHeader" style="margin-top: 5px; font-size:0.85rem;"></div>
            </div>
        </div>
        
        <div id="modalDescWrap" style="padding:0 25px 15px;">
            <div style="border-top:1px solid var(--gray-100); padding-top:15px;">
                <p style="font-size:0.8rem; font-weight:700; text-transform:uppercase; color:var(--gray-500); margin-bottom:8px;">Deskripsi</p>
                <p id="modalDesc" style="font-size:0.88rem; color:var(--gray-700); line-height:1.7; margin:0;"></p>
            </div>
        </div>

        
        <div style="padding:0 25px 25px;">
            <div style="border-top:1px solid var(--gray-100); padding-top:15px;">
                <p style="font-size:0.8rem; font-weight:700; text-transform:uppercase; color:var(--gray-500); margin-bottom:12px;">Ulasan Pengguna</p>
                
                
                <div id="modalReviewList" style="display:flex; flex-direction:column; gap:12px; max-height:200px; overflow-y:auto; margin-bottom:15px; padding-right:5px;"></div>
                
                
                <div id="modalReviewFormWrap" style="display:none; background:var(--gray-50); border:1px solid var(--gray-200); border-radius:10px; padding:15px; margin-top:10px;">
                    <form id="modalReviewForm" action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <p style="font-size:0.85rem; font-weight:700; color:var(--dark); margin-bottom:10px; display:flex; align-items:center; gap:6px;">
                            <i class="ti ti-edit" style="color:var(--primary);"></i> <span id="modalReviewFormTitle">Tulis Ulasan Anda</span>
                        </p>
                        <div style="display:flex; align-items:center; gap:8px; margin-bottom:10px;">
                            <label style="font-size:0.8rem; color:var(--gray-700); font-weight:600;">Rating:</label>
                            <select name="rating" required style="padding:4px 8px; border-radius:4px; border:1px solid var(--gray-300); font-size:0.85rem; color:#f1c40f; font-weight:bold;">
                                <option value="5">★★★★★ (5)</option>
                                <option value="4">★★★★☆ (4)</option>
                                <option value="3">★★★☆☆ (3)</option>
                                <option value="2">★★☆☆☆ (2)</option>
                                <option value="1">★☆☆☆☆ (1)</option>
                            </select>
                        </div>
                        <div style="margin-bottom:10px;">
                            <textarea name="review" placeholder="Tulis komentar atau ulasan Anda mengenai buku ini..." style="width:100%; height:60px; border-radius:6px; border:1px solid var(--gray-300); padding:8px; font-size:0.82rem; resize:none;" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary btn-sm" style="width:100%;">Kirim Ulasan</button>
                    </form>
                </div>
                
                <div id="modalReviewNotEligible" style="display:none; font-size:0.75rem; color:var(--gray-500); background:var(--gray-50); border-radius:8px; padding:10px; border:1px solid var(--gray-100); text-align:center;">
                    <i class="ti ti-lock" style="margin-right:4px;"></i> Anda harus pernah mengembalikan buku ini atau meminjamnya selama minimal 7 hari untuk dapat memberikan ulasan.
                </div>
            </div>
        </div>

        <div id="modalBorrowWrap" style="padding:0 25px 25px; display:none;">
            <div style="display:flex; flex-direction:column; gap:8px;">
                <form id="modalBorrowForm" action="<?php echo e(route('member.request_borrow')); ?>" method="POST" style="margin:0;">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" id="modalBookId" name="book_id" value="">
                    <button type="submit" class="btn btn-primary" style="width:100%; gap:8px; display:flex; align-items:center; justify-content:center;">
                        <i class="ti ti-send"></i> Pinjam Buku Ini
                    </button>
                </form>
                <a id="modalReadOnlineBtn" href="#" style="display:none; width:100%; gap:8px; align-items:center; justify-content:center; background-color:#4285F4; color:white; border:none; text-decoration:none; padding:8px 16px; border-radius:var(--border-radius); font-size:0.85rem; font-weight:600; text-align:center;">
                    <i class="ti ti-brand-google-drive"></i> Baca Online
                </a>
            </div>
        </div>
        <div id="modalReadOnlyWrap" style="padding:0 25px 25px; display:none;">
            <a id="modalReadOnlyBtn" href="#" style="width:100%; gap:8px; display:flex; align-items:center; justify-content:center; background-color:#4285F4; color:white; border:none; text-decoration:none; padding:10px 16px; border-radius:var(--border-radius); font-size:0.85rem; font-weight:600;">
                <i class="ti ti-brand-google-drive"></i> Baca Online
            </a>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php
    $memberStatus = auth()->user()->member->status;
    $bookDataArray = [];
    foreach($books as $b) {
        $reviews = [];
        foreach($b->reviews as $r) {
            $reviews[] = [
                'id'          => $r->id,
                'rating'      => $r->rating,
                'review'      => $r->review,
                'member_name' => $r->member->user->name,
                'date'        => $r->created_at->format('d M Y'),
            ];
        }

        $bookDataArray[$b->id] = [
            'id'             => $b->id,
            'title'          => $b->title,
            'author'         => $b->author,
            'publisher'      => $b->publisher,
            'year'           => $b->year,
            'category'       => $b->category,
            'barcode'        => $b->barcode,
            'description'    => $b->description,
            'cover'          => $b->cover_image ? asset($b->cover_image) : null,
            'stock'          => $b->available_stock,
            'totalStock'     => $b->stock,
            'isOnline'       => $b->is_online,
            'canBorrow'      => ($b->available_stock > 0 || !empty($b->drive_link)) && $memberStatus === 'active',
            'averageRating'  => $b->average_rating,
            'reviewsCount'   => $b->reviews->count(),
            'reviews'        => $reviews,
            'eligibleReview' => in_array($b->id, $returnedBookIds),
            'hasReviewed'    => in_array($b->id, $reviewedBookIds),
            'driveLink'      => $b->drive_link,
            'readUrl'        => $b->drive_link ? route('book.read', $b->id) : null,
        ];
    }
?>
<script>
const bookData = <?php echo json_encode($bookDataArray, 15, 512) ?>;

function filterCatalogCards(type) {
    const cards = document.querySelectorAll('#catalogGrid .book-card');
    cards.forEach(card => {
        const cardType = card.getAttribute('data-book-type');
        if (type === '' || type === cardType) {
            card.style.display = 'flex';
        } else {
            card.style.display = 'none';
        }
    });
}

function showBookDetail(id) {
    const b = bookData[id];
    if (!b) return;

    document.getElementById('modalBookTitle').textContent   = b.title;
    document.getElementById('modalCategory').textContent    = b.category;
    document.getElementById('modalAuthor').textContent      = 'Penulis: ' + b.author;
    document.getElementById('modalPublisher').textContent   = 'Penerbit: ' + b.publisher;
    document.getElementById('modalYear').textContent        = 'Tahun Terbit: ' + b.year;
    document.getElementById('modalBarcode').textContent     = 'Barcode: ' + b.barcode;

    const typeWrap = document.getElementById('modalTypeBadgeWrap');
    if (b.isOnline) {
        typeWrap.innerHTML = '<span class="badge badge-online"><i class="ti ti-device-tablet"></i> Online</span>';
    } else {
        typeWrap.innerHTML = '<span class="badge badge-offline"><i class="ti ti-book"></i> Offline</span>';
    }


    const stockEl = document.getElementById('modalStock');
    if (b.stock > 0) {
        stockEl.innerHTML = `<span style="color:var(--success)"><i class="ti ti-stack-2"></i> Tersedia: ${b.stock} / ${b.totalStock} Buku</span>`;
    } else {
        stockEl.innerHTML = `<span style="color:var(--primary)"><i class="ti ti-ban"></i> Stok Habis</span>`;
    }

    // Average rating display
    const ratingHeader = document.getElementById('modalRatingHeader');
    if (b.reviewsCount > 0) {
        let stars = '';
        for (let i = 1; i <= 5; i++) {
            stars += `<i class="${i <= Math.round(b.averageRating) ? 'ti ti-star-filled' : 'ti ti-star'}" style="color:#f1c40f;"></i> `;
        }
        ratingHeader.innerHTML = `${stars} <strong style="color:var(--dark); margin-left:4px;">${b.averageRating}</strong> <span style="color:var(--gray-500); font-size:0.75rem;">(${b.reviewsCount} Ulasan)</span>`;
    } else {
        ratingHeader.innerHTML = `<span style="color:var(--gray-500); font-style:italic; font-size:0.8rem;">Belum ada rating</span>`;
    }

    const descEl = document.getElementById('modalDesc');
    const descWrap = document.getElementById('modalDescWrap');
    if (b.description && b.description.trim() !== '') {
        descEl.textContent = b.description;
        descWrap.style.display = 'block';
    } else {
        descEl.textContent = 'Belum ada deskripsi untuk buku ini.';
        descWrap.style.display = 'block';
    }

    const coverImg  = document.getElementById('modalCover');
    const coverIcon = document.getElementById('modalCoverIcon');
    if (b.cover) {
        coverImg.src          = b.cover;
        coverImg.style.display = 'block';
        coverIcon.style.display = 'none';
    } else {
        coverImg.style.display  = 'none';
        coverIcon.style.display = 'flex';
    }

    const borrowWrap = document.getElementById('modalBorrowWrap');
    const readOnlineBtn = document.getElementById('modalReadOnlineBtn');
    const readOnlyWrap = document.getElementById('modalReadOnlyWrap');
    const readOnlyBtn = document.getElementById('modalReadOnlyBtn');

    if (b.canBorrow) {
        document.getElementById('modalBookId').value = b.id;
        borrowWrap.style.display = 'block';
        if (b.stock > 0) {
            borrowWrap.querySelector('button[type="submit"]').innerHTML = '<i class="ti ti-send"></i> Pinjam Buku Ini';
        } else {
            borrowWrap.querySelector('button[type="submit"]').innerHTML = '<i class="ti ti-send"></i> Minta Akses Baca';
        }
        if (b.driveLink) {
            readOnlineBtn.href = b.readUrl;
            readOnlineBtn.style.display = 'flex';
        } else {
            readOnlineBtn.style.display = 'none';
        }
        readOnlyWrap.style.display = 'none';
    } else {
        borrowWrap.style.display = 'none';
        if (b.driveLink) {
            readOnlyBtn.href = b.readUrl;
            readOnlyWrap.style.display = 'block';
        } else {
            readOnlyWrap.style.display = 'none';
        }
    }

    // Render Reviews
    const reviewList = document.getElementById('modalReviewList');
    reviewList.innerHTML = '';
    if (b.reviews.length > 0) {
        b.reviews.forEach(r => {
            let stars = '';
            for (let i = 1; i <= 5; i++) {
                stars += `<i class="${i <= r.rating ? 'ti ti-star-filled' : 'ti ti-star'}" style="color:#f1c40f; font-size:0.75rem;"></i>`;
            }
            const item = document.createElement('div');
            item.style.borderBottom = '1px solid var(--gray-100)';
            item.style.paddingBottom = '8px';
            item.innerHTML = `
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                    <strong style="font-size:0.82rem; color:var(--dark);">${r.member_name}</strong>
                    <span style="font-size:0.7rem; color:var(--gray-500);">${r.date}</span>
                </div>
                <div style="margin-bottom:4px;">${stars}</div>
                <p style="font-size:0.8rem; color:var(--gray-700); margin:0; line-height:1.4;">${r.review || '<em style="color:var(--gray-400)">Tidak ada komentar</em>'}</p>
            `;
            reviewList.appendChild(item);
        });
    } else {
        reviewList.innerHTML = `<div style="text-align:center; padding:15px; color:var(--gray-500); font-style:italic; font-size:0.82rem;">Belum ada ulasan untuk buku ini.</div>`;
    }

    // Handle Review Form Eligibility
    const formWrap = document.getElementById('modalReviewFormWrap');
    const notEligible = document.getElementById('modalReviewNotEligible');
    const reviewForm = document.getElementById('modalReviewForm');
    const formTitle = document.getElementById('modalReviewFormTitle');

    notEligible.style.display = 'none';
    formWrap.style.display = 'block';
    reviewForm.action = `/catalog/${b.id}/review`;
    
    if (b.hasReviewed) {
        formTitle.textContent = 'Perbarui Ulasan Anda';
    } else {
        formTitle.textContent = 'Tulis Ulasan Anda';
    }

    const modal = document.getElementById('bookDetailModal');
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeBookDetail() {
    document.getElementById('bookDetailModal').style.display = 'none';
    document.body.style.overflow = '';
}

document.getElementById('bookDetailModal').addEventListener('click', function(e) {
    if (e.target === this) closeBookDetail();
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Literawaslu\resources\views/dashboards/member_catalog.blade.php ENDPATH**/ ?>