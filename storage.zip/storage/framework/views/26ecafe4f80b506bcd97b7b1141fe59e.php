<?php $__env->startSection('title', 'Kelola Pengguna'); ?>
<?php $__env->startSection('header_title', 'Kelola Pengguna Perpustakaan'); ?>

<?php $__env->startSection('content'); ?>
<div class="card" style="margin-bottom: 25px;">
    <div class="card-body" style="padding: 20px;">
        <form action="<?php echo e(route('members.index')); ?>" method="GET" style="display: flex; gap: 10px; max-width: 500px;">
            <input type="text" name="search" class="form-control" placeholder="Cari nama, email, atau kode pengguna..." value="<?php echo e(request('search')); ?>">
            <button type="submit" class="btn btn-primary"><i class="ti ti-search"></i> Cari</button>
            <?php if(request('search')): ?>
                <a href="<?php echo e(route('members.index')); ?>" class="btn btn-outline"><i class="ti ti-rotate"></i> Atur Ulang</a>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
        <div style="display: flex; align-items: center; gap: 10px;">
            <h2>Daftar Pengguna Terdaftar</h2>
            <span class="badge badge-success"><?php echo e($members->count()); ?> Pengguna</span>
        </div>
        <?php if(auth()->user()->role === 'super_admin'): ?>
            <a href="<?php echo e(route('members.create')); ?>" class="btn btn-primary btn-sm" style="display: flex; align-items: center; gap: 6px; padding: 8px 16px; font-size: 0.85rem; border-radius: var(--border-radius); text-decoration: none;">
                <i class="ti ti-user-plus"></i> Tambah Pengguna
            </a>
        <?php endif; ?>
    </div>
    
    <div class="card-body">
        <?php if($members->isEmpty()): ?>
        <p style="text-align: center; color: var(--gray-600); padding: 20px;">Tidak ada data pengguna aktif yang ditemukan.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table-custom">
                    <thead>
                        <tr>
                            <th>Kode Pengguna</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <?php if(auth()->user()->role === 'super_admin'): ?>
                                <th>Info Keamanan</th>
                            <?php endif; ?>
                            <th>Total Peminjaman</th>
                            <th>Reward Poin</th>
                            <th>Batas Pinjam</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="font-family: monospace; font-weight: 700; color: var(--dark);"><?php echo e($member->member_code); ?></td>
                                <td><strong><?php echo e($member->user->name); ?></strong></td>
                                <td><?php echo e($member->user->email); ?></td>
                                <?php if(auth()->user()->role === 'super_admin'): ?>
                                    <td>
                                        <div style="font-size: 0.8rem;">
                                            <div style="color: var(--gray-600);">Tanya: <?php echo e($member->user->security_question); ?></div>
                                            <div style="font-weight: 600; color: var(--dark);">Jawab: <?php echo e($member->user->security_answer); ?></div>
                                        </div>
                                    </td>
                                <?php endif; ?>
                                <td><?php echo e($member->total_loans); ?> Kali</td>
                                <td>
                                    <span class="badge badge-warning"><?php echo e($member->points); ?></span>
                                </td>
                                <td><?php echo e($member->borrow_limit); ?> Buku</td>
                                <td>
                                    <?php if($member->status === 'active'): ?>
                                        <span class="badge badge-success"><i class="ti ti-check"></i> Terverifikasi</span>
                                    <?php elseif($member->status === 'pending'): ?>
                                        <span class="badge badge-warning"><i class="ti ti-clock"></i> Menunggu Verifikasi</span>
                                    <?php elseif($member->status === 'rejected'): ?>
                                        <span class="badge badge-danger"><i class="ti ti-x"></i> Ditolak</span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary"><?php echo e($member->status); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div style="display: flex; gap: 8px; align-items: center;">
                                        <?php if(auth()->user()->role === 'super_admin'): ?>
                                            <a href="<?php echo e(route('members.edit', $member->id)); ?>" class="btn btn-outline btn-sm" title="Edit Pengguna" style="padding: 6px 10px;">
                                                <i class="ti ti-pencil"></i>
                                            </a>
                                            <form action="<?php echo e(route('members.destroy', $member->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus pengguna ini dari sistem? Semua data relasi terkait juga akan terhapus.');" style="margin: 0;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-outline btn-sm" title="Hapus Pengguna" style="padding: 6px 10px; color: var(--primary);">
                                                    <i class="ti ti-trash"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Literawaslu\resources\views/members/index.blade.php ENDPATH**/ ?>