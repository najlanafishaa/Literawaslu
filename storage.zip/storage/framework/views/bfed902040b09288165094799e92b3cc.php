<?php $__env->startSection('title', 'Dashboard Admin'); ?>
<?php $__env->startSection('header_title', 'Dashboard Super Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="welcome-banner">
    <div style="position: relative; z-index: 5; flex: 1; min-width: 220px;">
        <h1>Selamat Datang di Portal Super Admin</h1>
        <p>Akses penuh sistem perpustakaan Literawaslu. Kelola buku, data pengguna, admin, dan pantau laporan transaksi.</p>
    </div>
</div>

<!-- Stats Dashboard Grid -->
<div class="grid-stats" style="margin-bottom: 25px;">
    <a href="<?php echo e(route('books.index')); ?>" class="stat-card card-red" style="text-decoration: none; cursor: pointer;">
        <div class="stat-info">
            <h3>TOTAL KOLEKSI BUKU</h3>
            <p><?php echo e($totalBooks); ?> Buku</p>
        </div>
        <div class="stat-icon">
            <i class="ti ti-book-2"></i>
        </div>
    </a>
    
    <a href="<?php echo e(route('borrows.history')); ?>" class="stat-card card-dark" style="text-decoration: none; cursor: pointer;">
        <div class="stat-info">
            <h3>SEDANG DIPINJAM</h3>
            <p><?php echo e($totalTransactions); ?> Transaksi</p>
        </div>
        <div class="stat-icon">
            <i class="ti ti-book-upload"></i>
        </div>
    </a>
    
    <a href="<?php echo e(route('members.index')); ?>" class="stat-card card-yellow" style="text-decoration: none; cursor: pointer;">
        <div class="stat-info">
            <h3>PENGGUNA TERDAFTAR</h3>
            <p><?php echo e($totalMembers); ?> Pengguna</p>
        </div>
        <div class="stat-icon">
            <i class="ti ti-users"></i>
        </div>
    </a>

    <a href="<?php echo e(route('borrows.history')); ?>" class="stat-card card-red" style="text-decoration: none; cursor: pointer;">
        <div class="stat-info">
            <h3>KETERLAMBATAN</h3>
            <p style="<?php echo e($overdueCount > 0 ? 'color:#d62027;' : ''); ?>"><?php echo e($overdueCount); ?> Transaksi</p>
        </div>
        <div class="stat-icon">
            <i class="ti ti-alert-circle"></i>
        </div>
    </a>
</div>

<!-- Monthly Borrowing Trend Chart Card -->
<div class="card" style="margin-bottom: 25px;">
    <div class="card-header">
        <h2><i class="ti ti-chart-line" style="color: var(--primary); margin-right: 8px;"></i> Tren Peminjaman per Bulan</h2>
    </div>
    <div class="card-body" style="position: relative; height: 300px;">
        <canvas id="dashboardMonthlyChart"></canvas>
    </div>
</div>

<!-- Admin Quick Action Links -->
<div class="card" style="margin-bottom: 25px;">
    <div class="card-header">
        <h2><i class="ti ti-compass" style="color: var(--primary); margin-right: 8px;"></i> Navigasi Pintar Kelola Data</h2>
    </div>
    <div class="card-body" style="padding: 16px 20px; display: flex; gap: 12px; flex-wrap: wrap;">
        <a href="<?php echo e(route('books.index')); ?>" class="btn btn-secondary" style="flex: 1; min-width: 140px;">
            <i class="ti ti-book-2"></i> Kelola Data Buku
        </a>
        <a href="<?php echo e(route('members.index')); ?>" class="btn btn-secondary" style="flex: 1; min-width: 140px;">
            <i class="ti ti-users"></i> Kelola Data Pengguna
        </a>
        <a href="<?php echo e(route('officers.index')); ?>" class="btn btn-secondary" style="flex: 1; min-width: 140px;">
            <i class="ti ti-shield-lock"></i> Kelola Data Admin
        </a>
        <a href="<?php echo e(route('reports.index')); ?>" class="btn btn-primary" style="flex: 1; min-width: 140px;">
            <i class="ti ti-file-invoice"></i> Cetak &amp; Lihat Laporan
        </a>
    </div>
</div>

<!-- Online Borrow Approval Section -->
<div class="card" style="margin-bottom: 25px;">
    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
        <h2 style="margin: 0;"><i class="ti ti-checklist" style="color: var(--primary); margin-right: 8px;"></i> Daftar Pengajuan Peminjaman Online</h2>
        <span class="badge badge-success"><?php echo e(isset($pendingBorrowsList) ? $pendingBorrowsList->count() : 0); ?> Pengajuan Menunggu</span>
    </div>
    <div class="card-body">
        <?php if(!isset($pendingBorrowsList) || $pendingBorrowsList->isEmpty()): ?>
            <p style="text-align: center; color: var(--gray-600); padding: 20px;">Tidak ada pengajuan peminjaman online yang perlu disetujui saat ini.</p>
        <?php else: ?>
            <div class="table-responsive" style="-webkit-overflow-scrolling: touch;">
                <table class="table-custom">
                    <thead>
                        <tr>
                            <th>Nama Pengguna</th>
                            <th>Judul Buku</th>
                            <th>Jenis Buku</th>
                            <th>Tanggal Pengajuan</th>
                            <th>Status Pengajuan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pendingBorrowsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <strong style="color: var(--dark);"><?php echo e($borrow->member->user->name); ?></strong>
                                    <div style="font-size: 0.8rem; color: var(--gray-600); font-weight: 600;"><?php echo e($borrow->member->member_code); ?></div>
                                </td>
                                <td>
                                    <strong style="color: var(--primary);"><?php echo e($borrow->book->title); ?></strong>
                                    <div style="font-size: 0.78rem; color: var(--gray-600);">Barcode: <?php echo e($borrow->book->barcode); ?> &bull; Stok: <?php echo e($borrow->book->available_stock); ?></div>
                                </td>
                                <td>
                                    <?php if($borrow->book->is_online): ?>
                                        <span class="badge badge-online">Online</span>
                                    <?php else: ?>
                                        <span class="badge badge-offline">Offline</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(\Carbon\Carbon::parse($borrow->borrow_date)->format('d M Y, H:i')); ?></td>
                                <td>
                                    <span class="badge badge-pending"><i class="ti ti-hourglass"></i> Menunggu Persetujuan</span>
                                </td>
                                <td>
                                    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                                        <form action="<?php echo e(route('verifications.borrow.approve', $borrow->id)); ?>" method="POST" style="margin: 0;">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-secondary btn-sm">
                                                <i class="ti ti-check"></i> Setujui
                                            </button>
                                        </form>
                                        <form action="<?php echo e(route('verifications.borrow.reject', $borrow->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menolak pengajuan ini?');" style="margin: 0;">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-outline btn-sm">
                                                <i class="ti ti-x"></i> Tolak
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="dashboard-grid">
    <!-- Left Column: Recent Borrowing Log -->
    <div class="card">
        <div class="card-header">
            <h2><i class="ti ti-history" style="color: var(--primary); margin-right: 8px;"></i> Transaksi Peminjaman Terbaru</h2>
        </div>
        <div class="card-body">
            <?php if($recentBorrows->isEmpty()): ?>
                <p style="text-align: center; color: var(--gray-600); padding: 20px;">Belum ada riwayat transaksi peminjaman.</p>
            <?php else: ?>
                <div class="table-responsive" style="-webkit-overflow-scrolling: touch;">
                    <table class="table-custom">
                        <thead>
                            <tr>
                                <th>Buku</th>
                                <th>Jenis Buku</th>
                                <th>Peminjam</th>
                                <th>Tanggal Pinjam</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $recentBorrows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div style="font-weight: 600; color: var(--dark);"><?php echo e($borrow->book->title); ?></div>
                                        <div style="font-size: 0.78rem; color: var(--gray-600);"><?php echo e($borrow->book->author); ?></div>
                                    </td>
                                    <td>
                                        <?php if($borrow->book->is_online): ?>
                                            <span class="badge badge-online">Online</span>
                                        <?php else: ?>
                                            <span class="badge badge-offline">Offline</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($borrow->member->user->name); ?></td>
                                    <td><?php echo e($borrow->borrow_date->format('d M Y')); ?></td>
                                    <td>
                                        <?php if($borrow->status === 'returned'): ?>
                                            <span class="badge badge-success">Selesai</span>
                                        <?php elseif($borrow->status === 'borrowed'): ?>
                                            <span class="badge badge-warning">Dipinjam</span>
                                        <?php elseif($borrow->status === 'pending'): ?>
                                            <span class="badge badge-info" style="background:rgba(59,130,246,.12);color:#1d4ed8;border:1px solid #bfdbfe;">Menunggu</span>
                                        <?php elseif($borrow->status === 'terlambat'): ?>
                                            <span class="badge badge-danger">Terlambat</span>
                                        <?php elseif($borrow->status === 'rejected'): ?>
                                            <span class="badge badge-danger">Ditolak</span>
                                        <?php else: ?>
                                            <span class="badge badge-warning"><?php echo e(ucfirst($borrow->status)); ?></span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Right Column: Most Borrowed Books -->
    <div class="card">
        <div class="card-header">
            <h2><i class="ti ti-trending-up" style="color: var(--secondary); margin-right: 8px;"></i> Buku Terpopuler</h2>
        </div>
        <div class="card-body">
            <?php if($popularBooks->isEmpty()): ?>
                <p style="text-align: center; color: var(--gray-600); padding: 20px;">Belum ada data peminjaman populer.</p>
            <?php else: ?>
                <ul style="list-style: none; display: flex; flex-direction: column; gap: 15px; padding: 0; margin: 0;">
                    <?php $__currentLoopData = $popularBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li style="display: flex; align-items: center; justify-content: space-between; padding-bottom: 12px; border-bottom: 1px solid var(--gray-100);">
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <span style="font-size: 1.1rem; font-weight: 700; color: <?php echo e($index == 0 ? 'var(--secondary)' : ($index == 1 ? 'var(--primary)' : 'var(--gray-600)')); ?>;">
                                    #<?php echo e($index + 1); ?>

                                </span>
                                <div>
                                    <div style="font-weight: 600; color: var(--dark); display: flex; align-items: center; gap: 6px; flex-wrap: wrap;">
                                        <?php echo e($popular->book->title); ?>

                                        <?php if($popular->book->is_online): ?>
                                            <span class="badge badge-online">Online</span>
                                        <?php else: ?>
                                            <span class="badge badge-offline">Offline</span>
                                        <?php endif; ?>
                                    </div>
                                    <div style="font-size: 0.8rem; color: var(--gray-600);"><?php echo e($popular->book->author); ?></div>
                                </div>
                            </div>
                            <span class="badge badge-success" style="font-weight: 700;"><?php echo e($popular->total); ?>x Pinjam</span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const monthlyData = <?php echo json_encode($monthlyTrends ?? [], 15, 512) ?>;
        const labels = Object.keys(monthlyData);
        const dataValues = Object.values(monthlyData);

        const ctx = document.getElementById('dashboardMonthlyChart');
        if (ctx) {
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels.length > 0 ? labels : ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun'],
                    datasets: [{
                        label: 'Jumlah Peminjaman Buku',
                        data: dataValues.length > 0 ? dataValues : [0, 0, 0, 0, 0, 0],
                        borderColor: '#D62027',
                        backgroundColor: 'rgba(214, 32, 39, 0.08)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.3,
                        pointBackgroundColor: '#F5B025',
                        pointRadius: 5
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: true,
                            position: 'top'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0
                            }
                        }
                    }
                }
            });
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Literawaslu\resources\views/dashboards/admin.blade.php ENDPATH**/ ?>