<?php $__env->startSection('title', 'Verifikasi'); ?>
<?php $__env->startSection('header_title', 'Verifikasi Pengguna & Peminjaman'); ?>

<?php $__env->startSection('content'); ?>
<div class="card" style="margin-bottom: 25px;">
    <div class="card-header">
        <h2 style="margin: 0;"><i class="ti ti-user-check" style="color: var(--primary); margin-right: 8px;"></i> Verifikasi Pendaftaran Pengguna Baru</h2>
    </div>
    
    <div class="card-body">
        <?php if($pendingMembers->isEmpty()): ?>
            <p style="text-align: center; color: var(--gray-600); padding: 20px;">Tidak ada pendaftaran pengguna baru yang perlu diverifikasi.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table-custom">
                    <thead>
                        <tr>
                            <th>Kode Pengguna</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Tgl Mendaftar</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pendingMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="font-weight: bold; color: var(--primary);"><?php echo e($member->member_code); ?></td>
                                <td><?php echo e($member->user->name); ?></td>
                                <td><?php echo e($member->user->email); ?></td>
                                <td><?php echo e($member->created_at->format('d M Y, H:i')); ?></td>
                                <td>
                                    <div style="display: flex; gap: 8px;">
                                        <form action="<?php echo e(route('verifications.member.approve', $member->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-secondary btn-sm">
                                                <i class="ti ti-check"></i> Setujui
                                            </button>
                                        </form>
                                        <form action="<?php echo e(route('verifications.member.reject', $member->id)); ?>" method="POST" onsubmit="return confirm('Tolak pendaftaran member ini?');">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-outline btn-sm">
                                                <i class="ti ti-x"></i> Tolak
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="card" style="margin-bottom: 25px;">
    <div class="card-header">
        <h2 style="margin: 0;"><i class="ti ti-device-laptop" style="color: var(--secondary); margin-right: 8px;"></i> Verifikasi Peminjaman Online</h2>
    </div>
    
    <div class="card-body">
        <?php if($pendingBorrows->isEmpty()): ?>
            <p style="text-align: center; color: var(--gray-600); padding: 20px;">Tidak ada permintaan peminjaman buku yang perlu diverifikasi.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table-custom">
                    <thead>
                        <tr>
                            <th>Pengguna</th>
                            <th>Buku</th>
                            <th>Jenis Buku</th>
                            <th>Tgl Pinjam (Request)</th>
                            <th>Rencana Tgl Kembali</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pendingBorrows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div style="font-weight: bold;"><?php echo e($borrow->member->user->name); ?></div>
                                    <small style="color: var(--gray-600);"><?php echo e($borrow->member->member_code); ?></small>
                                </td>
                                <td>
                                    <div style="font-weight: bold;"><?php echo e($borrow->book->title); ?></div>
                                    <small style="color: var(--gray-600);">Stok: <?php echo e($borrow->book->available_stock); ?></small>
                                </td>
                                <td>
                                    <?php if($borrow->book->is_online): ?>
                                        <span class="badge badge-online">Online</span>
                                    <?php else: ?>
                                        <span class="badge badge-offline">Offline</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(\Carbon\Carbon::parse($borrow->borrow_date)->format('d M Y')); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($borrow->due_date)->format('d M Y')); ?></td>
                                <td>
                                    <div style="display: flex; gap: 8px;">
                                        <form action="<?php echo e(route('verifications.borrow.approve', $borrow->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-secondary btn-sm">
                                                <i class="ti ti-check"></i> Setujui
                                            </button>
                                        </form>
                                        <form action="<?php echo e(route('verifications.borrow.reject', $borrow->id)); ?>" method="POST" onsubmit="return confirm('Tolak permintaan pinjaman ini?');">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-outline btn-sm">
                                                <i class="ti ti-x"></i> Tolak
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>



<div class="card">
    <div class="card-header">
        <h2 style="margin: 0;"><i class="ti ti-key" style="color: var(--primary); margin-right: 8px;"></i> Verifikasi Atur Ulang Kata Sandi Pengguna</h2>
    </div>
    
    <div class="card-body">
        <?php if($pendingResets->isEmpty()): ?>
            <p style="text-align: center; color: var(--gray-600); padding: 20px;">Tidak ada permintaan atur ulang kata sandi yang perlu diverifikasi.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table-custom">
                    <thead>
                        <tr>
                            <th>Nama Pengguna</th>
                            <th>Email</th>
                            <th>No. Telepon</th>
                            <th>Tgl Request</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pendingResets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div style="font-weight: bold;"><?php echo e($req->user->name); ?></div>
                                    <small style="color: var(--gray-600);"><?php echo e($req->user->member ? $req->user->member->member_code : 'N/A'); ?></small>
                                </td>
                                <td><?php echo e($req->user->email); ?></td>
                                <td><?php echo e($req->user->phone ?? '-'); ?></td>
                                <td><?php echo e($req->created_at->format('d M Y, H:i')); ?></td>
                                <td>
                                    <div style="display: flex; gap: 8px;">
                                        <form action="<?php echo e(route('verifications.reset.approve', $req->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-secondary btn-sm">
                                                <i class="ti ti-check"></i> Setujui
                                            </button>
                                        </form>
                                        <form action="<?php echo e(route('verifications.reset.reject', $req->id)); ?>" method="POST" onsubmit="return confirm('Tolak permintaan atur ulang kata sandi ini?');">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-outline btn-sm">
                                                <i class="ti ti-x"></i> Tolak
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Literawaslu\resources\views/dashboards/petugas_verification.blade.php ENDPATH**/ ?>