<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Models\Borrow;
use App\Models\Member;
use Illuminate\Http\Request;
use Carbon\Carbon;

class BorrowController extends Controller
{
    /**
     * Show borrowing & transaction portal for Petugas/Admins.
     */
    public function index()
    {
        Borrow::syncActiveBorrowStates();

        $activeBorrows = Borrow::whereIn('status', ['borrowed', 'terlambat'])
            ->with(['member.user', 'book'])
            ->orderBy('borrow_date', 'desc')
            ->get();

        $members = Member::with('user')->get();
        $books = Book::where('is_available', true)->get();

        return view('dashboards.petugas_borrows', compact('activeBorrows', 'members', 'books'));
    }

    /**
     * Handle borrowing (Checkout).
     */
    public function checkout(Request $request)
    {
        $request->validate([
            'member_code' => 'required|string',
            'barcode' => 'required|string',
        ], [
            'member_code.required' => 'Kode member wajib diisi/dipindai.',
            'barcode.required' => 'Barcode buku wajib diisi/dipindai.',
        ]);

        // Find member
        $member = Member::where('member_code', $request->member_code)->first();
        if (!$member) {
            return back()->with('error', "Member dengan kode '{$request->member_code}' tidak ditemukan.");
        }

        Borrow::syncActiveBorrowStates($member);
        $member->refresh();

        if ($member->status !== 'active') {
            return back()->with('error', "Gagal memproses peminjaman. Akun member '{$member->user->name}' tidak aktif.");
        }

        if ($member->points <= 0) {
            return back()->with('error', "Gagal memproses peminjaman. Akun member '{$member->user->name}' dibekukan karena poin habis.");
        }

        if ($member->hasActiveBorrow()) {
            return back()->with('error', "Member '{$member->user->name}' masih memiliki buku yang sedang dipinjam. Harus dikembalikan terlebih dahulu.");
        }



        // Find book
        $book = Book::where('barcode', $request->barcode)->first();
        if (!$book) {
            return back()->with('error', "Buku dengan barcode '{$request->barcode}' tidak ditemukan.");
        }
        if ($book->available_stock <= 0) {
            return back()->with('error', "Stok buku '{$book->title}' sedang habis.");
        }

        $loanDuration = (int) SettingController::getSetting('loan_duration', 7);

        // Process checkout
        Borrow::create([
            'member_id' => $member->id,
            'book_id'   => $book->id,
            'borrow_date' => Carbon::today(),
            'due_date'    => Carbon::today()->addDays($loanDuration),
            'status'      => 'borrowed',
            'fine_amount' => 0,
            'fine_status' => 'none',
        ]);

        // Update book availability stock
        $book->decrement('available_stock');
        $book->update(['is_available' => $book->available_stock > 0]);

        return back()->with('success', "Buku '{$book->title}' berhasil dipinjam oleh '{$member->user->name}'. Jatuh tempo: " . Carbon::today()->addDays($loanDuration)->format('d M Y') . ".");
    }

    /**
     * Handle returning (Checkin) using barcode scan.
     */
    public function checkin(Request $request)
    {
        $request->validate([
            'barcode' => 'required|string',
        ], [
            'barcode.required' => 'Scan/masukkan barcode buku untuk pengembalian.',
        ]);

        $book = Book::where('barcode', $request->barcode)->first();
        if (!$book) {
            return back()->with('error', "Buku dengan barcode '{$request->barcode}' tidak ditemukan.");
        }

        $borrow = Borrow::where('book_id', $book->id)
            ->whereIn('status', ['borrowed', 'terlambat'])
            ->first();

        if (!$borrow) {
            return back()->with('error', "Buku '{$book->title}' tidak terdaftar dalam peminjaman aktif.");
        }

        $member = $borrow->member;
        $returnDate = Carbon::today();
        $dueDate = Carbon::parse($borrow->due_date);

        $daysLate = $returnDate->greaterThan($dueDate)
            ? (int) $returnDate->diffInDays($dueDate)
            : 0;

        if ($daysLate > 0) {
            $pointDeduction = $daysLate <= 3 ? $daysLate * 10 : 30;
        } else {
            $pointDeduction = 0;
        }

        // Sanksi ganti buku jika terlambat > 3 hari (mulai hari ke-4)
        if ($daysLate > 3) {
            $borrow->fine_status = 'unpaid'; // wajib ganti 1 buku fisik
        } else {
            $borrow->fine_status = 'none';
        }
        $borrow->fine_amount = 0;

        $borrow->return_date = $returnDate;
        $borrow->status = 'returned';

        $borrow->save();

        $member->total_loans += 1;

        $isOnline = !empty($book->drive_link);
        $basePoints = $isOnline ? 1 : 5;

        if ($pointDeduction > 0) {
            // Deduct late penalty points
            $member->points = max(0, $member->points - $pointDeduction);
            \App\Models\PointHistory::create([
                'member_id' => $member->id,
                'type' => 'deduct',
                'points' => $pointDeduction,
                'description' => "Pengurangan poin keterlambatan pengembalian buku '{$book->title}' ({$daysLate} hari)",
            ]);
            
            // Suspend member if points reach 0
            if ($member->points <= 0) {
                $member->status = 'suspended';
            }
        } else {
            $member->points += $basePoints;
            \App\Models\PointHistory::create([
                'member_id' => $member->id,
                'type' => 'earn',
                'points' => $basePoints,
                'description' => "Poin peminjaman buku '{$book->title}' (" . ($isOnline ? 'Online' : 'Offline') . ")",
            ]);
        }

        $member->save();

        // Kembalikan stok buku
        $book->increment('available_stock');
        $book->update(['is_available' => $book->available_stock > 0]);

        $message = "Pengembalian berhasil diproses. Terima kasih telah mengembalikan buku tepat waktu.";

        if ($daysLate > 3) {
            return back()->with('warning', $message);
        } elseif ($daysLate > 0) {
            return back()->with('warning', $message);
        } else {
            return back()->with('success', $message);
        }
    }

    public function payFine(Borrow $borrow)
    {
        if ($borrow->fine_status === 'unpaid') {
            $borrow->fine_status = 'paid';
            $borrow->fine_amount = 1;
            $borrow->save();

            return back()->with('success', "Penyerahan donasi 1 buku fisik pengganti oleh member '{$borrow->member->user->name}' berhasil dikonfirmasi.");
        }

        return back()->with('info', 'Sanksi buku fisik sudah dipenuhi sebelumnya.');
    }

    public function history(Request $request)
    {
        $filter = $request->get('filter', 'all');
        $startDate = null;
        $endDate = null;
        $filterLabel = 'Semua Waktu';

        switch ($filter) {
            case 'today':
                $startDate = Carbon::today();
                $endDate = Carbon::today();
                $filterLabel = 'Hari Ini';
                break;
            case 'week':
                $startDate = Carbon::now()->startOfWeek();
                $endDate = Carbon::now()->endOfWeek();
                $filterLabel = 'Minggu Ini';
                break;
            case 'month':
                $startDate = Carbon::now()->startOfMonth();
                $endDate = Carbon::now()->endOfMonth();
                $filterLabel = 'Bulan Ini';
                break;
            case 'year':
                $startDate = Carbon::now()->startOfYear();
                $endDate = Carbon::now()->endOfYear();
                $filterLabel = 'Tahun Ini';
                break;
            case 'custom':
                $startDate = $request->get('start_date') ? Carbon::parse($request->get('start_date')) : null;
                $endDate = $request->get('end_date') ? Carbon::parse($request->get('end_date')) : null;
                $filterLabel = ($startDate && $endDate) ? $startDate->format('d M Y') . ' – ' . $endDate->format('d M Y') : 'Kustom';
                break;
        }

        Borrow::syncActiveBorrowStates();

        $query = Borrow::with(['member.user', 'book']);

        if ($startDate && $endDate) {
            $query->whereBetween('borrow_date', [$startDate, $endDate]);
        }

        $borrows = $query->orderBy('created_at', 'desc')->get();

        return view('dashboards.admin_borrows', compact('borrows', 'filterLabel'));
    }

    /**
     * Apply on-demand late point deductions for active overdue borrows.
     * This runs when the borrow list is loaded (no cron needed).
     * Points are deducted once per day tracked by a daily check via due_date.
     */
    private function applyLatePointDeduction(Borrow $borrow): void
    {
        if (!in_array($borrow->status, ['borrowed', 'terlambat'])) return;

        $today = Carbon::today();
        $dueDate = Carbon::parse($borrow->due_date);
        $daysLate = $today->greaterThan($dueDate) ? (int) $today->diffInDays($dueDate) : 0;

        if ($daysLate <= 0) return;

        $member = $borrow->member;

        $needsSave = false;

        // Ubah status menjadi terlambat sejak hari pertama keterlambatan
        if ($daysLate > 0 && $borrow->status !== 'terlambat') {
            $borrow->status = 'terlambat';
            $needsSave = true;
        }

        // Terlambat > 3 hari (hari ke-4 ke atas) -> wajib ganti 1 buku fisik
        if ($daysLate > 3 && $borrow->fine_status !== 'unpaid') {
            $borrow->fine_status = 'unpaid'; // Perlu ganti 1 buku fisik
            $needsSave = true;
        }

        if ($needsSave) {
            $borrow->save();
        }
    }
}
